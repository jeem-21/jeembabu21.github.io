# Shihab Hossain Personal Site
1. `index.html` = public website
2. `admin.html` = hidden admin dashboard
3. GitHub Pages-এ দুই ফাইল একই folder-এ upload করুন।
4. Admin খুলতে সরাসরি `/admin.html` ব্যবহার করুন।
5. Demo password: `admin123` — অবশ্যই পরিবর্তন করতে হবে।

IMPORTANT: এটি GitHub Pages-এর জন্য frontend/localStorage version। এতে Admin data browser-local থাকে; সত্যিকারের secure multi-device admin-এর জন্য backend/authentication (যেমন Supabase/Firebase) লাগবে।
